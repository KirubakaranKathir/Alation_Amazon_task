package Basetest;
import java.io.File;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.model.Log;

import testPages.booksDataCatalog;
import testPages.BookDetails;
import testPages.KindleDetails;
import testPages.OtherSeller;
import testPages.PaperBackDetailsUsedBook;
import testPages.PaperBackDetailsNewBook;


public class TestSuite {
	WebDriver driver;
	Logger Log=Logger.getLogger(Log.class.getName());
    
	
	@BeforeTest
    public void OpenAmazon() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        driver.get("https://www.amazon.com/");
        
        Log.info("Amazon opened successfully");

        
	}
        @Test   
        public void booksDataCatalog()throws InterruptedException
       {
       try
       {
       booksDataCatalog catalogList= new booksDataCatalog(driver);
       //catalogList.VerifyLogo();
       
       
       catalogList.SelectDept("Books");
       Log.info("Books option selected");
       Thread.sleep(1000);
       
       catalogList.Searchvalue("data catalog");
       Log.info("Entered the value");
       Thread.sleep(1000);
       
       catalogList.ClickOnSearchButton();
       Log.info("Clicked the Search option");
       Thread.sleep(1000);
       }
       catch(Exception e) {

    	   Log.info("Element not found");
       }
      
      }
        @Test(dependsOnMethods= {"booksDataCatalog"})

        public void bookDetails() throws InterruptedException
        {
        	try
        {
        	BookDetails Result= new BookDetails(driver);
        	Result.clickOnFirstSearch();
        	 Log.info("Clicked the first result");
        	Thread.sleep(1000);
        	
        	
        	Assert.assertTrue(Result.getTitleVerify());
        	 Log.info("Title is verified");
        	Thread.sleep(1000);
        	
        	Result.getTitleName();
        	 Log.info(Result.getTitleName());
        	System.out.println(Result.getTitleName());
        	Thread.sleep(1000);
        	
        	Assert.assertTrue(Result.getEditionVerify());
        	 Log.info("Edition is verified");
        	Thread.sleep(1000);
        	
        	Result.getEditionName();
        	 Log.info("Edition"+Result.getEditionName());
        	System.out.println("Edition:"+Result.getEditionName());
        	
        	//Verify Author 1 Name
        	Assert.assertTrue(Result.verifyAuthor1());
        	 Log.info("Author1 is verified");
        	Thread.sleep(1000);
        	
        	//Get the Author 1 Name
        	Result.getAuthor1Name();
        	 Log.info("Author 1:"+Result.getAuthor1Name());
        	System.out.println("Author 1:"+Result.getAuthor1Name());
        	
        	//Verify the Author 2 Name
        	Assert.assertTrue(Result.verifyAuthor2());
        	 Log.info("Author2 is verified");
        	Thread.sleep(1000);
        	
        	//Get the Author 2 Name
        	Result.getAuthor2Name();
        	 Log.info("Author 2:"+Result.getAuthor2Name());
        	System.out.println("Author 2:"+Result.getAuthor2Name());
        	
        	//Verify the Author 3 Name
        	Assert.assertTrue(Result.verifyAuthor3());
        	 Log.info("Author3 is verified");
        	Thread.sleep(1000);
        	
        	//Get the Author 3 Name
        	Result.getAuthor3Name();
        	 Log.info("Author 3:"+Result.getAuthor3Name());
        	System.out.println("Author 3:"+Result.getAuthor3Name());
        	Thread.sleep(1000);
        	
        	//Get the number of reviews
        	Result.getReviewDetails();
        	 Log.info("Reviews counts are:"+Result.getReviewDetails());
        	System.out.println("Reviews counts are:"+Result.getReviewDetails());
        	Thread.sleep(2000);
        }
        	catch(Exception e)
        	{
        		 Log.info("Element not fount");
        	}
        	
        	}
        
       @Test(dependsOnMethods= {"bookDetails"})
        	public void kindleDetails() throws InterruptedException
        	{
        	try
        	{
        		KindleDetails kindle=new KindleDetails(driver);
        		kindle.selectKindleTab();
        		 Log.info("Clicked the Kindle Tab");
        		Thread.sleep(1000);
            	
        		kindle.kindleBuyPrice();
        		 Log.info("Buy price of kindle:"+kindle.kindleBuyPrice());
            	System.out.println("Buy price of kindle:"+kindle.kindleBuyPrice());
            	Thread.sleep(1000);
            	
            	kindle.originalPriceListAndOffer();
            	 Log.info("Original price of kindle and Offer details: "+kindle.originalPriceListAndOffer());
            	System.out.println("Original price of kindle and Offer details: "+kindle.originalPriceListAndOffer());
            	Thread.sleep(1000);
            	
            	Assert.assertTrue(kindle.VerifyfeaturesTitle());
            	 Log.info("ebook features Title is verified");
            	System.out.println("ebook features Title is verified");
            	Thread.sleep(1000);
            	
            	kindle.kindleFeatures();
            	 Log.info("ebook features listed");
        		Thread.sleep(1000);
            	
        		kindle.supportDevicesLink();
        		 Log.info("Support Devices Link is verified");
            	System.out.println("Support Devices Link is verified");
            	Thread.sleep(1000);
            	
            	kindle.soldBy();
            	 Log.info("Sold By "+kindle.soldBy());
        		Thread.sleep(1000);
            	System.out.println("Sold By "+kindle.soldBy());
            	
        	}
        	catch(Exception e)
        	{
        		 Log.info("Element Not Found");
        	}
        	}
        @Test(dependsOnMethods= {"kindleDetails"})
        public void paperBackDetails() throws InterruptedException
        {
        try
        {
        	PaperBackDetailsUsedBook paperBack=new PaperBackDetailsUsedBook(driver);
        	paperBack.selectPaperBackTab();
        	 Log.info("PaperBack Tab clicked");
        	System.out.println("PaperBack Tab clicked");
        	Thread.sleep(1000);
        	
        	paperBack.buyUsedClick();
        	 Log.info("Buy used clicked");
        	System.out.println("Buy used clicked");
        	Thread.sleep(1000);
        	
        	paperBack.bookUsedCondition();
        	 Log.info("Book Condition: "+paperBack.bookUsedCondition());
        	System.out.println("Book Condition: "+paperBack.bookUsedCondition());
        	Thread.sleep(1000);
        	
        	Assert.assertTrue(paperBack.stockVerify());
        	 Log.info("Book in Stock");
        	System.out.println("Book in Stock");
        	Thread.sleep(1000);
        	
        	paperBack.soldBy();
        	 Log.info("Used Book Sold By: "+paperBack.soldBy());
        	System.out.println("Used Book Sold By: "+paperBack.soldBy());
        	Thread.sleep(1000);
        	
        	paperBack.usedBookPrice();
        	 Log.info("Used Book Price: "+paperBack.usedBookPrice());
        	System.out.println("Used Book Price: "+paperBack.usedBookPrice());
        	Thread.sleep(1000);
        	
        	paperBack.usedBookCountAndPrice();
        	 Log.info("Used Book Count and Price: "+paperBack.usedBookCountAndPrice());
        	System.out.println("Used Book Count and Price: "+paperBack.usedBookCountAndPrice());
        	Thread.sleep(1000);
        	
        	paperBack.shippingChargeForUsedBook();
        	 Log.info("Shipping Charge for Used Book: "+paperBack.shippingChargeForUsedBook());
        	System.out.println("Shipping Charge for Used Book:"+paperBack.shippingChargeForUsedBook());
        	Thread.sleep(1000);
        	
        	paperBack.warningMessageForUsedItems();
        	 Log.info("Warning Message for Used Book: "+paperBack.warningMessageForUsedItems());
        	System.out.println("Warning Message for Used Book:"+paperBack.warningMessageForUsedItems());
        	Thread.sleep(3000);
        	}
        catch(Exception e)
        {
        	 Log.info("Element not found");
        }
        }
        	@Test(dependsOnMethods= {"paperBackDetails"})
        	public void paperBackNewBookDetails() throws InterruptedException
        	{
        	try
        	{
            //PaperBack New Buy Price
        	PaperBackDetailsNewBook paperBackNew= new PaperBackDetailsNewBook(driver);
        	paperBackNew.clickedOnBuyNew();
        	 Log.info("Clicked Buy new option ");
        	System.out.println("Clicked Buy new option ");
        	Thread.sleep(3000);
        	
        	paperBackNew.newPaperbackPrice();
        	 Log.info("Price of new Paperback: "+paperBackNew.newPaperbackPrice());
            System.out.println("Price of new Paperback:"+paperBackNew.newPaperbackPrice());
        	Thread.sleep(1000);
        	
        	paperBackNew.newPaperbackstockVerify();
        	 Log.info("Stock status :"+paperBackNew.newPaperbackstockVerify());
        	System.out.println("Stock status :"+paperBackNew.newPaperbackstockVerify());
        	Thread.sleep(1000);
        	
        	paperBackNew.shipAndSoldBy();
        	 Log.info("Shipping and Sold By: "+paperBackNew.shipAndSoldBy());
        	System.out.println(paperBackNew.shipAndSoldBy());
        	Thread.sleep(1000);
        	
        	//Get the New book details
        	paperBackNew.newBookUsedDetails();
        	 Log.info("New Book Used Details: "+paperBackNew.newBookUsedDetails());
        	System.out.println("New Book Used Details:"+paperBackNew.newBookUsedDetails());
        	Thread.sleep(1000);
        	}
        	catch(Exception e)
        	{
        		 Log.info("Element not found");
        	}
        	
        	
        	}
        	@Test(dependsOnMethods= {"paperBackNewBookDetails"})
        	public void otherSellerTab() throws InterruptedException
        	{
        		try
        		{
        		OtherSeller otherseller=new OtherSeller(driver);
        		
        		otherseller.clickonOtherSellerTab();
        		Log.info("Cliced on Seller Tab ");
            	System.out.println("Cliced on Seller Tab ");
            	Thread.sleep(2000);
            	
            	otherseller.getNewBookBuyDetails();
            	Log.info("New Book Buy Details: "+otherseller.getNewBookBuyDetails());
            	System.out.println("New Book Buy Details: "+otherseller.getNewBookBuyDetails());
            	Thread.sleep(2000);
            	
            	otherseller.getOldBookBuyDetails();
            	Log.info("Old Book Buy Details: "+otherseller.getOldBookBuyDetails());
            	System.out.println("Old Book Buy Details: "+otherseller.getOldBookBuyDetails());
            	Thread.sleep(2000);
            	
            	otherseller.getTotalCountDetails();
            	Log.info("Total Buy Details: "+otherseller.getTotalCountDetails());
            	System.out.println("Total Buy Details: "+otherseller.getTotalCountDetails());
            	Thread.sleep(2000);
        		}
        		catch(Exception e)
        		{
        			Log.info("Element not found");
        		}
        	}
        	
               @AfterTest
        	public void driverClose()
        	{
            	  
        	driver.close();
        	Log.info("Driver Close");
        	
		}
               
	}

