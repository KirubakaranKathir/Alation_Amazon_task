package testPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
//import org.testng.Assert;

public class booksDataCatalog {
	
	WebDriver driver;
	
	 public booksDataCatalog(WebDriver driver){

	        this.driver = driver;

	        //This initElements method will create all WebElements

	        PageFactory.initElements(driver, this);

	    }  
	 
	@FindBy(xpath="//div[@id='nav-logo']/a/span") WebElement logo;
	@FindBy(id="searchDropdownBox") WebElement selectdept;
	@FindBy(id="twotabsearchtextbox") WebElement entersearch;
	@FindBy(xpath="//input[@value='Go']") WebElement clicksearch;
    
/*public void VerifyLogo()
{
	logo.isDisplayed();
	System.out.println(logo);
	boolean expected = true;
    Assert.assertEquals(logo,expected);	
}*/
	
//Select the Books department in dropdown	
public void SelectDept(String department)
{
	Select dept=new Select(selectdept);
	dept.selectByVisibleText(department);
	
}
//Enter the value in search box
public void Searchvalue(String value)
{
	entersearch.clear();
	entersearch.sendKeys(value);
}
//Click on Search button
public void ClickOnSearchButton()
{
	clicksearch.click();
	
}

}
