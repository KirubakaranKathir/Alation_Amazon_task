package testPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaperBackDetailsNewBook {
	WebDriver driver;
	
	 public PaperBackDetailsNewBook(WebDriver driver){

	        this.driver = driver;

	        //This initElements method will create all WebElements

	        PageFactory.initElements(driver, this);

	    }  
	 @FindBy(xpath="//*[@id=\"newOfferAccordionRow\"]/div/div[1]/a/i") WebElement selectBuyNew;
     @FindBy(xpath="//*[@id=\"newOfferAccordionRow\"]/div/div[1]/a/h5/div/div[2]/span[2]") WebElement buyNewPrice;
     @FindBy(xpath="//*[@id=\"availability\"]/span") WebElement buyNewStockVerify;
     @FindBy(xpath="//*[@id=\"merchant-info\"]") WebElement shipAndSoldBy;
     @FindBy(xpath="//*[@id=\"addToCart\"]/div[1]/div[1]/a") WebElement newBookUsed;
     
   //Clicked Buy New item
	 public void clickedOnBuyNew()
	 {
		 selectBuyNew.click(); 
	 }
	 //Get the new book buy price
	 public String newPaperbackPrice()
	 {
		 return buyNewPrice.getText(); 
	 }
	 
	 //Get the stock details
	 public String newPaperbackstockVerify()
	 {
		 return buyNewStockVerify.getText();
	 }
	 //Get the shipper and sold by name
	 public String shipAndSoldBy()
	 {
		 return shipAndSoldBy.getText(); 
	 }
	//Get the new book used details
	 public String newBookUsedDetails()
	 {
		 return newBookUsed.getText();
	 }

	
	 
}
