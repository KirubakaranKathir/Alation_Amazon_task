package testPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaperBackDetailsUsedBook {
		WebDriver driver;
		
		 public PaperBackDetailsUsedBook(WebDriver driver){

		        this.driver = driver;

		        //This initElements method will create all WebElements

		        PageFactory.initElements(driver, this);

		    }  
		 //For Used Paperback
		 @FindBy(xpath="//*[@id=\"mediaTab_heading_1\"]/a/span/div[1]/span") WebElement selectPaperbackTab;
         @FindBy(xpath="//*[@id=\"usedOfferAccordionRow\"]/div/div[1]/a/i") WebElement buyUsedClick;
         @FindBy(xpath="//*[@id=\"usedOfferAccordionRow\"]/div/div[2]/div/div/div[1]/div/div[1]/div[1]/span[2]/a/strong") WebElement bookCondition;
         @FindBy(xpath="//*[@id=\"usedOfferAccordionRow\"]/div/div[2]/div/div/div[1]/div/div[1]/div[2]/span") WebElement stockVerify;
         @FindBy(xpath="//*[@id=\"usedOfferAccordionRow\"]/div/div[2]/div/div/div[1]/div/div[1]/div[2]/a") WebElement soldBy;
         @FindBy(xpath="//*[@id=\"usedOfferAccordionRow\"]/div/div[1]/a/h5/div/div[2]/span[2]") WebElement usedBookPrice;
         @FindBy(xpath="//*[@id=\"addToCart\"]/div[1]/div") WebElement usedCount;
         @FindBy(xpath="//*[@id=\"addToCart\"]/div[2]/div/div") WebElement shippingCharge; 
         @FindBy(xpath="//*[@id=\"accessCodeWarning\"]/span") WebElement warningMessage;
         
                
       //Click on PaperBack Tab
		 public void selectPaperBackTab()
		 {
			 selectPaperbackTab.click();
		 }
		 //Click on Buy Used Radio button
		 public void buyUsedClick()
		 {
			 buyUsedClick.click();
		 }
		//Get the Used book Condition details
		 
		 public String bookUsedCondition()
		 {
			 return bookCondition.getText();
		 }
		 
		 //Verify the stock of the book
		 public boolean stockVerify()
		 {
			 return stockVerify.getText().contains("In Stock.");
		 }
		 //Get the SoldBy name
		 public String soldBy()
		 {
			 return soldBy.getText();
		 }
		 //Get the Used book price
		 public String usedBookPrice()
		 {
			 return usedBookPrice.getText();
		 }
		 //Get the Used  book count and price
		 public String usedBookCountAndPrice()
		 {
			 return usedCount.getText();
		 }
		 //Get the Shipping charges
		 public String shippingChargeForUsedBook()
		 {
			 return shippingCharge.getText();
		 }
		 //Get the Warning messages
		 public String warningMessageForUsedItems()
		 {
			 return warningMessage.getText();
		 }
		 
		 }
