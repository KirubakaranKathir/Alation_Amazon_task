package testPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OtherSeller {
		WebDriver driver;
		
		 public OtherSeller(WebDriver driver){

		        this.driver = driver;

		        //This initElements method will create all WebElements

		        PageFactory.initElements(driver, this);

		    } 
		 @FindBy(xpath="//*[@id=\"mediaTab_heading_2\"]/a/span/div[1]/span") WebElement clickonOtherSellers;
         @FindBy(xpath="//*[@id=\"mediaOlp\"]/div/div/div/div[1]/div[2]/div/span[1]") WebElement newcount;
         @FindBy(xpath="//*[@id=\"mediaOlp\"]/div/div/div/div[1]/div[2]/div/span[2]") WebElement oldcount;
         @FindBy(xpath="//*[@id=\"singleLineOlp\"]/span") WebElement totalCount;
         
       //Click on other seller tab
		 public void clickonOtherSellerTab()
		 {
			 clickonOtherSellers.click(); 
		 }
		//Get the count and price of new book
		 public String getNewBookBuyDetails()
		 {
			 return newcount.getText();
		 }
	    //Get the count and price of old book
		 public String getOldBookBuyDetails()
		 {
			 return oldcount.getText();
		 }
	    //Get the count and price of total book
		 public String getTotalCountDetails()
		 {
			 return totalCount.getText();
		 }
}
