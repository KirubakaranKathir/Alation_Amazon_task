package testPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

	public class BookDetails {
		
		WebDriver driver;
		
		 public BookDetails(WebDriver driver){

		        this.driver = driver;

		        //This initElements method will create all WebElements

		        PageFactory.initElements(driver, this);

		    }  
		 
		 @FindBy(xpath="//span[@class='a-size-medium a-color-base a-text-normal']") WebElement Clickonlist;
		 @FindBy(xpath="//span[contains(text(),'Data and Analytics')]") WebElement Titleverify;
		 @FindBy(xpath="//span[@id='bookEdition']") WebElement BookEdition;
		 @FindBy(xpath="//a[@class='a-link-normal contributorNameID']") WebElement Author1;
		 @FindBy(linkText="Gregory Lampshire") WebElement Author2;
		 @FindBy(linkText="Dan Meers") WebElement Author3;
		 @FindBy(xpath="//span[@id='acrCustomerReviewText']") WebElement review;

		 
		 

		 //Click on First Result 
		public void clickOnFirstSearch()
		{
			Clickonlist.click();
		}
		
		//Verify the Title of the book
		public boolean getTitleVerify()
		{
			return Titleverify.getText().contains("Data and Analytics Playbook");
			}
		
		//Get the Title of the book
		public String getTitleName()
		{
			return Titleverify.getText();
		}
		//Verify the Edition of the book
		public boolean getEditionVerify()
		{
			return BookEdition.getText().contains("1st Edition");
			}
		
		//Get the Edition of the book
		public String getEditionName()
		{
			return BookEdition.getText();
		}
		
		/*public boolean getAuthorNameVerify()
		{
			return Author1.getText().contains("Lowell Fryman");
			}*/
		
		//Verify the Author1 Name
		public boolean verifyAuthor1()
		{
			return Author1.getText().contains("Lowell");
			}
		//Get the Author 1 Name
		public String getAuthor1Name()
		{
			return Author1.getText();
		}
		//Verify the Author2 Name
		public boolean verifyAuthor2()
		{
			return Author2.getText().contains("Gregory");
			}
		//Get the Author2 Name
		public String getAuthor2Name()
		{
			return Author2.getText();
		}
		//Verify the Author3 Name
		
		public boolean verifyAuthor3()
		{
			return Author3.getText().contains("Dan");
			}
		//Get the Author3 Name
		public String getAuthor3Name()
		{
			return Author3.getText();
		}
		//Get the Review count of the book
		public String getReviewDetails()
		{
			return review.getText();
		}
}
