package testPages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class KindleDetails {
	WebDriver driver;
	
	 public KindleDetails(WebDriver driver){

	        this.driver = driver;

	        //This initElements method will create all WebElements

	        PageFactory.initElements(driver, this);

	    }  
        @FindBy(xpath="//span[@class='a-size-large mediaTab_title']") WebElement selectkindle;
        @FindBy(xpath="//div/div[2]/div/div/div/div[2]/span[2]") WebElement kindleBuyprice;
        @FindBy(xpath="//div[2]/div/div[2]/div/div/div/span") WebElement originalPriceList;
        @FindBy(xpath="//span[contains(.,'eBook features:')]") WebElement featuresTitle;
        @FindBy(xpath="//ul[@id='eTextbookBulletList']") List<WebElement> kindleFeatures;
        @FindBy(linkText="See all supported devices") WebElement supportedDevicesLink;
        @FindBy(xpath="//div[2]/div/div/div/div[3]/span[2]") WebElement soldBy;
        
        //Click on Kindle Tab
        public void selectKindleTab()
        {
        	selectkindle.click();
        }
        //Get the Buy price
        public String kindleBuyPrice()
        {
        	return kindleBuyprice.getText();
        }
        //Get the original price without offer
        public String originalPriceListAndOffer()
        {
        	return originalPriceList.getText();
        }
        //Verify the feature Title
        public boolean VerifyfeaturesTitle()
        {
        	return featuresTitle.getText().contains("eBook");
        }
        //Get the ebook features
        public void kindleFeatures() {
        	
        	for( WebElement features : kindleFeatures ) {
        		System.out.println(features.getText());
        	}

        }
        //Verify the supported devices info link
        public void supportDevicesLink()
        {
        	if(supportedDevicesLink.isDisplayed())
        	{
        		System.out.println("The link is present");
        	}
        	else
        	{
        		System.out.println("The link isn't present");
        	}
        }
//Get the SoldBy name
        public String soldBy()
        {
        	return soldBy.getText();
        }

}